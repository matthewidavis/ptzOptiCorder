## Left off on Stream Scheduling ##
## [IDEA] add camera group, location, etc. for easier identification & sorting ##
## [IDEA] motion detection ##
## [IDEA] preset recall with stream start / stop ##
## [IDEA] preview enlarge with PTZF and Preset Controls ##
## [IDEA] Dropbox \ GDrive support ##

<img width="950" alt="image" src="https://github.com/user-attachments/assets/e58d5e3b-9c91-4245-a53f-299828335cd9" />
<img width="949" alt="image" src="https://github.com/user-attachments/assets/cd3ac408-1a99-425b-bb47-4aecff04ddff" />
<img width="948" alt="image" src="https://github.com/user-attachments/assets/bd397d96-6897-4218-b24a-4a82025bf3e0" />
<img width="950" alt="image" src="https://github.com/user-attachments/assets/00351ab9-bb2e-4d78-adcb-e5117e829445" />
<img width="936" alt="image" src="https://github.com/user-attachments/assets/167cce7c-05f5-4ffd-9517-4f9199391644" />
<img width="938" alt="image" src="https://github.com/user-attachments/assets/0899183a-4d57-4672-aaf1-6e3db98ca703" />
<img width="947" alt="image" src="https://github.com/user-attachments/assets/e76f2621-e8da-42cf-a9b4-9f4fb1c91333" />
<img width="946" alt="image" src="https://github.com/user-attachments/assets/9ea0b722-57f5-4365-9755-62aa7822354a" />

